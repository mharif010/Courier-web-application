<?php include('header.php'); ?>

<div class="content-wrapper">


  <div class="row">
    <div class="col-sm-6 mb-4 mb-xl-0">
      <h4 class="font-weight-bold text-dark">Site Dashboard from here.</h4>



    </div>
  </div>


</div>
<!-- content-wrapper ends -->
<?php include('footer.php'); ?>